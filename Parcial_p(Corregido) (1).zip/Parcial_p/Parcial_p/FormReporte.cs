﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parcial_p.entities;
using Parcial_p.Reporte;

namespace Parcial_p
{
    public partial class FormReporte : Form
    {
        private PeliculaReporte peliculaReporte = new PeliculaReporte();
        public FormReporte()
        {
            InitializeComponent();
        }

        private void MostrarPelicula(List<Pelicula> lista)
        {
            listViewReporte.Items.Clear();
            foreach( Pelicula pelicula in lista)
            {
                ListViewItem fila = new ListViewItem(pelicula.Codigo);
                fila.SubItems.Add(pelicula.Nombre);
                fila.SubItems.Add(pelicula.Genero);
                fila.SubItems.Add(pelicula.Estado);
                fila.SubItems.Add(pelicula.Duracion.ToString());
                fila.SubItems.Add(pelicula.TaquillaGenerada.ToString());
                fila.SubItems.Add(pelicula.AnioEstreno);
                listViewReporte.Items.Add(fila);
            }
        }
        
        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btListarPeliculasTaquillerasDirector_Click(object sender, EventArgs e)
        {
            if(tbDirector.Text == "")
            {
                MessageBox.Show("Ingrese un director");
                return;
            }

            MostrarPelicula(peliculaReporte.Listarlaspeliculasmastaquillerasporcadadirector(tbDirector.Text));

            tbDirector.Text = "";

        }

        private void btListarPeliculaTaquillerasAnio_Click(object sender, EventArgs e)
        {
         
            if(tbAnio.Text == "")
            {
                MessageBox.Show("Ingrese un año");
                return;
            }

            MostrarPelicula(peliculaReporte.Listarlaspeliculasmastaquillerasdeunanioespecifico(tbAnio.Text));

            tbAnio.Text = "";
        }

        private void btListarPeliculasSegunCaracteristicas_Click(object sender, EventArgs e)
        {
            if(cbCaracteristicas.Text == "")
            {
                MessageBox.Show("Ingrese una ocpion");
                return;
            }

            if(cbCaracteristicas.Text == "Genero")
            {
                tbDuracionReporte.Text = "";
                MostrarPelicula(peliculaReporte.Listarlaspeliculassegúnsuscaracteristicasgenero(cbGeneroReporte.Text));
            }
            else
            {
                MostrarPelicula(peliculaReporte.Listarlaspeliculassegúnsuscaracteristicas(int.Parse(tbDuracionReporte.Text), cbGeneroReporte.Text));
            }

            cbCaracteristicas.Text = "";
            tbDuracionReporte.Text = "";
            cbGeneroReporte.Text = ""; 
        }
    }
}
