﻿using System;
using Parcial_p.entities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_p.Controller
{
    public class DirectorController
    {
        private static List<Director> directores = new List<Director>();
        public DirectorController() { }

        public bool Existe (String Dni)
        {
            return directores.Exists(elemento => elemento.DNI.Equals(Dni));
        }

        public void Registrar(Director director)
        {
            directores.Add(director);
        }

        public static List<Director> ListarTodo()
        {
            return directores;
        }
  
    }
}
