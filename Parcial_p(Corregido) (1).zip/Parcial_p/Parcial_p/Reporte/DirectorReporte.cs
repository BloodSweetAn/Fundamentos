﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parcial_p.Controller;
using Parcial_p.entities;

namespace Parcial_p.Reporte
{
    public class DirectorReporte
    {
        private DirectorController directorController = new DirectorController();

        public DirectorReporte() { }

        public bool Registrar(Director director)
        {
            if (directorController.Existe(director.DNI))
            {
                return false;
            }
            else
            {
                directorController.Registrar(director);
                return true;
            }
        } 

        public List<Director> ListarTodo()
        {
            return DirectorController.ListarTodo();
        }

    }
}
