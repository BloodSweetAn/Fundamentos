﻿
namespace Parcial_p
{
    partial class FormDirector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbDni = new System.Windows.Forms.TextBox();
            this.tbNombreCompleto = new System.Windows.Forms.TextBox();
            this.cbSexo = new System.Windows.Forms.ComboBox();
            this.tbTelefono = new System.Windows.Forms.TextBox();
            this.btRegistrar = new System.Windows.Forms.Button();
            this.btVerPeliculas = new System.Windows.Forms.Button();
            this.btSalirDirector = new System.Windows.Forms.Button();
            this.btReportes = new System.Windows.Forms.Button();
            this.listViewDirector = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cbEstado = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "DNI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre Completo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Sexo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Estado";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Teléfono ";
            // 
            // tbDni
            // 
            this.tbDni.Location = new System.Drawing.Point(204, 43);
            this.tbDni.Name = "tbDni";
            this.tbDni.Size = new System.Drawing.Size(185, 22);
            this.tbDni.TabIndex = 5;
            // 
            // tbNombreCompleto
            // 
            this.tbNombreCompleto.Location = new System.Drawing.Point(204, 89);
            this.tbNombreCompleto.Name = "tbNombreCompleto";
            this.tbNombreCompleto.Size = new System.Drawing.Size(185, 22);
            this.tbNombreCompleto.TabIndex = 6;
            // 
            // cbSexo
            // 
            this.cbSexo.FormattingEnabled = true;
            this.cbSexo.Items.AddRange(new object[] {
            "Masculino",
            "Femenino"});
            this.cbSexo.Location = new System.Drawing.Point(204, 136);
            this.cbSexo.Name = "cbSexo";
            this.cbSexo.Size = new System.Drawing.Size(185, 24);
            this.cbSexo.TabIndex = 7;
            // 
            // tbTelefono
            // 
            this.tbTelefono.Location = new System.Drawing.Point(205, 234);
            this.tbTelefono.Name = "tbTelefono";
            this.tbTelefono.Size = new System.Drawing.Size(184, 22);
            this.tbTelefono.TabIndex = 9;
            // 
            // btRegistrar
            // 
            this.btRegistrar.Location = new System.Drawing.Point(158, 298);
            this.btRegistrar.Name = "btRegistrar";
            this.btRegistrar.Size = new System.Drawing.Size(103, 30);
            this.btRegistrar.TabIndex = 10;
            this.btRegistrar.Text = "Registrar";
            this.btRegistrar.UseVisualStyleBackColor = true;
            this.btRegistrar.Click += new System.EventHandler(this.btRegistrar_Click);
            // 
            // btVerPeliculas
            // 
            this.btVerPeliculas.Location = new System.Drawing.Point(143, 345);
            this.btVerPeliculas.Name = "btVerPeliculas";
            this.btVerPeliculas.Size = new System.Drawing.Size(135, 31);
            this.btVerPeliculas.TabIndex = 11;
            this.btVerPeliculas.Text = "Ver Peliculas";
            this.btVerPeliculas.UseVisualStyleBackColor = true;
            this.btVerPeliculas.Click += new System.EventHandler(this.btVerPeliculas_Click);
            // 
            // btSalirDirector
            // 
            this.btSalirDirector.Location = new System.Drawing.Point(176, 448);
            this.btSalirDirector.Name = "btSalirDirector";
            this.btSalirDirector.Size = new System.Drawing.Size(75, 26);
            this.btSalirDirector.TabIndex = 12;
            this.btSalirDirector.Text = "Salir";
            this.btSalirDirector.UseVisualStyleBackColor = true;
            this.btSalirDirector.Click += new System.EventHandler(this.btSalirDirector_Click);
            // 
            // btReportes
            // 
            this.btReportes.Location = new System.Drawing.Point(166, 394);
            this.btReportes.Name = "btReportes";
            this.btReportes.Size = new System.Drawing.Size(95, 33);
            this.btReportes.TabIndex = 13;
            this.btReportes.Text = "Reportes";
            this.btReportes.UseVisualStyleBackColor = true;
            this.btReportes.Click += new System.EventHandler(this.btReportes_Click);
            // 
            // listViewDirector
            // 
            this.listViewDirector.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.listViewDirector.HideSelection = false;
            this.listViewDirector.Location = new System.Drawing.Point(420, 23);
            this.listViewDirector.Name = "listViewDirector";
            this.listViewDirector.Size = new System.Drawing.Size(484, 441);
            this.listViewDirector.TabIndex = 14;
            this.listViewDirector.UseCompatibleStateImageBehavior = false;
            this.listViewDirector.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "DNI";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nombre Completo";
            this.columnHeader2.Width = 120;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Sexo";
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Estado";
            this.columnHeader4.Width = 80;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Telefono";
            this.columnHeader5.Width = 80;
            // 
            // cbEstado
            // 
            this.cbEstado.FormattingEnabled = true;
            this.cbEstado.Items.AddRange(new object[] {
            "Activo",
            "Suspendido",
            "Vitalicio"});
            this.cbEstado.Location = new System.Drawing.Point(205, 185);
            this.cbEstado.Name = "cbEstado";
            this.cbEstado.Size = new System.Drawing.Size(184, 24);
            this.cbEstado.TabIndex = 15;
            // 
            // FormDirector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 499);
            this.Controls.Add(this.cbEstado);
            this.Controls.Add(this.listViewDirector);
            this.Controls.Add(this.btReportes);
            this.Controls.Add(this.btSalirDirector);
            this.Controls.Add(this.btVerPeliculas);
            this.Controls.Add(this.btRegistrar);
            this.Controls.Add(this.tbTelefono);
            this.Controls.Add(this.cbSexo);
            this.Controls.Add(this.tbNombreCompleto);
            this.Controls.Add(this.tbDni);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormDirector";
            this.Text = "FormDirector";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbDni;
        private System.Windows.Forms.TextBox tbNombreCompleto;
        private System.Windows.Forms.ComboBox cbSexo;
        private System.Windows.Forms.TextBox tbTelefono;
        private System.Windows.Forms.Button btRegistrar;
        private System.Windows.Forms.Button btVerPeliculas;
        private System.Windows.Forms.Button btSalirDirector;
        private System.Windows.Forms.Button btReportes;
        private System.Windows.Forms.ListView listViewDirector;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ComboBox cbEstado;
    }
}