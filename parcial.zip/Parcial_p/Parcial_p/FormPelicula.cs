﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Parcial_p.entities;
using Parcial_p.Reporte;

namespace Parcial_p
{
    public partial class FormPelicula : Form
    {
        private PeliculaReporte peliculaReporte = new PeliculaReporte();
        private String Codigo;
        public FormPelicula(String codigo)
        {
            InitializeComponent();
            this.Codigo = codigo;
            MostrarPelicula(peliculaReporte.ListarTodo(codigo));
        }

        private void MostrarPelicula(List<Pelicula> lista)
        {
            listViewPelicula.Items.Clear();

            foreach(Pelicula pelicula in lista)
            {
                ListViewItem fila = new ListViewItem(pelicula.Codigo);
                fila.SubItems.Add(pelicula.Nombre);
                fila.SubItems.Add(pelicula.Genero);
                fila.SubItems.Add(pelicula.Estado);
                fila.SubItems.Add(pelicula.Duracion.ToString());
                fila.SubItems.Add(pelicula.TaquillaGenerada.ToString());
                fila.SubItems.Add(pelicula.AnioEstreno);
                listViewPelicula.Items.Add(fila);

            }

        }

        private void btRegistrar_Click(object sender, EventArgs e)
        {
            if(tbCodigo.Text == "" || tbAnioEstreno.Text == "" || tbDuracion.Text == ""||
                tbEstado.Text == "" | tbNombre.Text == "" || cbGenero.Text == "" || tbTaquillaGenerada.Text == "")
            {
                MessageBox.Show("Ingrese todos los campos");
                return;
            }

            Pelicula pelicula = new Pelicula()
            {
                Nombre = tbNombre.Text,
                Codigo = tbCodigo.Text,
                Duracion =int.Parse(tbDuracion.Text),
                AnioEstreno = tbAnioEstreno.Text,
                Estado = tbEstado.Text,
                Genero = cbGenero.Text,
                TaquillaGenerada = int.Parse(tbTaquillaGenerada.Text)
            };

            bool registrado = peliculaReporte.Registrar(Codigo, pelicula);
            if(!registrado)
            {
                MessageBox.Show("Ingrese un codigo diferente");
                return;
            }

            tbAnioEstreno.Text = "";
            tbNombre.Text = "";
            tbCodigo.Text = "";
            tbDuracion.Text = "";
            tbEstado.Text = "";
            cbGenero.Text = "";
            tbTaquillaGenerada.Text = "";

            MostrarPelicula(peliculaReporte.ListarTodo(Codigo));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
