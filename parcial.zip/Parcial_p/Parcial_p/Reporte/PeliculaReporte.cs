﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Parcial_p.Controller;
using Parcial_p.entities;

namespace Parcial_p.Reporte
{
    public class PeliculaReporte
    {
        private PeliculaController peliculaController = new PeliculaController();

        public PeliculaReporte() { }

        public bool Registrar(String Dni , Pelicula pelicula)
        {
            if (peliculaController.Existe(pelicula.Codigo))
            {
                return false;
            }
            else
            {
                peliculaController.Registrar(Dni, pelicula);
                return true;
            }
        }

        public List<Pelicula> ListarTodo(String Dni)
        {
            return peliculaController.ListarTodo(Dni);
        }

        public List<Pelicula> Listarlaspeliculasmastaquillerasdeunanioespecifico(String anio)
        {
            return peliculaController.Listarlaspeliculasmastaquillerasdeunanioespecifico(anio);
        }

        public List<Pelicula> Listarlaspeliculasmastaquillerasporcadadirector(String Nombre)
        {
            return peliculaController.ListarLasPeliculasMasTaquillerasDeUnAnioEspecifico(Nombre);
        }

        public List<Pelicula> Listarlaspeliculassegúnsuscaracteristicas(int duracion , String genero)
        {
            return peliculaController.Listarlaspeliculassegúnsuscaracteristicas(duracion, genero);
        }
        public List<Pelicula> Listarlaspeliculassegúnsuscaracteristicasgenero(String genero)
        {
            return peliculaController.Listarlaspeliculassegúnsuscaracteristicasgenero(genero);
        }
    }
}
