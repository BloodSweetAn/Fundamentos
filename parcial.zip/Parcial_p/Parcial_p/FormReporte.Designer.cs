﻿
namespace Parcial_p
{
    partial class FormReporte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btListarPeliculasTaquillerasDirector = new System.Windows.Forms.Button();
            this.btListarPeliculaTaquillerasAnio = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbCaracteristicas = new System.Windows.Forms.ComboBox();
            this.btListarPeliculasSegunCaracteristicas = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbDirector = new System.Windows.Forms.TextBox();
            this.tbAnio = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.listViewReporte = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btSalir = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbGeneroReporte = new System.Windows.Forms.ComboBox();
            this.tbDuracionReporte = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btListarPeliculasTaquillerasDirector
            // 
            this.btListarPeliculasTaquillerasDirector.Location = new System.Drawing.Point(25, 304);
            this.btListarPeliculasTaquillerasDirector.Name = "btListarPeliculasTaquillerasDirector";
            this.btListarPeliculasTaquillerasDirector.Size = new System.Drawing.Size(362, 35);
            this.btListarPeliculasTaquillerasDirector.TabIndex = 0;
            this.btListarPeliculasTaquillerasDirector.Text = "Listar las películas más taquilleras por cada director ";
            this.btListarPeliculasTaquillerasDirector.UseVisualStyleBackColor = true;
            this.btListarPeliculasTaquillerasDirector.Click += new System.EventHandler(this.btListarPeliculasTaquillerasDirector_Click);
            // 
            // btListarPeliculaTaquillerasAnio
            // 
            this.btListarPeliculaTaquillerasAnio.Location = new System.Drawing.Point(25, 418);
            this.btListarPeliculaTaquillerasAnio.Name = "btListarPeliculaTaquillerasAnio";
            this.btListarPeliculaTaquillerasAnio.Size = new System.Drawing.Size(362, 35);
            this.btListarPeliculaTaquillerasAnio.TabIndex = 1;
            this.btListarPeliculaTaquillerasAnio.Text = "Listar las películas más taquilleras de un año específico";
            this.btListarPeliculaTaquillerasAnio.UseVisualStyleBackColor = true;
            this.btListarPeliculaTaquillerasAnio.Click += new System.EventHandler(this.btListarPeliculaTaquillerasAnio_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Caracteristicas";
            // 
            // cbCaracteristicas
            // 
            this.cbCaracteristicas.FormattingEnabled = true;
            this.cbCaracteristicas.Items.AddRange(new object[] {
            "Genero",
            "Genero y duracion minima"});
            this.cbCaracteristicas.Location = new System.Drawing.Point(167, 53);
            this.cbCaracteristicas.Name = "cbCaracteristicas";
            this.cbCaracteristicas.Size = new System.Drawing.Size(220, 24);
            this.cbCaracteristicas.TabIndex = 3;
            // 
            // btListarPeliculasSegunCaracteristicas
            // 
            this.btListarPeliculasSegunCaracteristicas.Location = new System.Drawing.Point(25, 198);
            this.btListarPeliculasSegunCaracteristicas.Name = "btListarPeliculasSegunCaracteristicas";
            this.btListarPeliculasSegunCaracteristicas.Size = new System.Drawing.Size(362, 30);
            this.btListarPeliculasSegunCaracteristicas.TabIndex = 4;
            this.btListarPeliculasSegunCaracteristicas.Text = "Listar las películas según sus características";
            this.btListarPeliculasSegunCaracteristicas.UseVisualStyleBackColor = true;
            this.btListarPeliculasSegunCaracteristicas.Click += new System.EventHandler(this.btListarPeliculasSegunCaracteristicas_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 260);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Director";
            // 
            // tbDirector
            // 
            this.tbDirector.Location = new System.Drawing.Point(167, 260);
            this.tbDirector.Name = "tbDirector";
            this.tbDirector.Size = new System.Drawing.Size(220, 22);
            this.tbDirector.TabIndex = 6;
            // 
            // tbAnio
            // 
            this.tbAnio.Location = new System.Drawing.Point(167, 380);
            this.tbAnio.Name = "tbAnio";
            this.tbAnio.Size = new System.Drawing.Size(220, 22);
            this.tbAnio.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 383);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Año";
            // 
            // listViewReporte
            // 
            this.listViewReporte.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.listViewReporte.HideSelection = false;
            this.listViewReporte.Location = new System.Drawing.Point(405, 35);
            this.listViewReporte.Name = "listViewReporte";
            this.listViewReporte.Size = new System.Drawing.Size(592, 472);
            this.listViewReporte.TabIndex = 9;
            this.listViewReporte.UseCompatibleStateImageBehavior = false;
            this.listViewReporte.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Codigo";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Nombre";
            this.columnHeader2.Width = 80;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Genero";
            this.columnHeader3.Width = 80;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Estado";
            this.columnHeader4.Width = 80;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Duracion";
            this.columnHeader5.Width = 80;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Taquilla";
            this.columnHeader6.Width = 80;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Año de estreno";
            this.columnHeader7.Width = 100;
            // 
            // btSalir
            // 
            this.btSalir.Location = new System.Drawing.Point(167, 480);
            this.btSalir.Name = "btSalir";
            this.btSalir.Size = new System.Drawing.Size(87, 35);
            this.btSalir.TabIndex = 10;
            this.btSalir.Text = "Salir";
            this.btSalir.UseVisualStyleBackColor = true;
            this.btSalir.Click += new System.EventHandler(this.btSalir_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "Genero";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "Duracion";
            // 
            // cbGeneroReporte
            // 
            this.cbGeneroReporte.FormattingEnabled = true;
            this.cbGeneroReporte.Items.AddRange(new object[] {
            "Terror",
            "Comedia",
            "Drama",
            "Ciencia Ficcion",
            "Anime"});
            this.cbGeneroReporte.Location = new System.Drawing.Point(167, 99);
            this.cbGeneroReporte.Name = "cbGeneroReporte";
            this.cbGeneroReporte.Size = new System.Drawing.Size(220, 24);
            this.cbGeneroReporte.TabIndex = 13;
            // 
            // tbDuracionReporte
            // 
            this.tbDuracionReporte.Location = new System.Drawing.Point(167, 146);
            this.tbDuracionReporte.Name = "tbDuracionReporte";
            this.tbDuracionReporte.Size = new System.Drawing.Size(220, 22);
            this.tbDuracionReporte.TabIndex = 14;
            // 
            // FormReporte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 530);
            this.Controls.Add(this.tbDuracionReporte);
            this.Controls.Add(this.cbGeneroReporte);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btSalir);
            this.Controls.Add(this.listViewReporte);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbAnio);
            this.Controls.Add(this.tbDirector);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btListarPeliculasSegunCaracteristicas);
            this.Controls.Add(this.cbCaracteristicas);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btListarPeliculaTaquillerasAnio);
            this.Controls.Add(this.btListarPeliculasTaquillerasDirector);
            this.Name = "FormReporte";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btListarPeliculasTaquillerasDirector;
        private System.Windows.Forms.Button btListarPeliculaTaquillerasAnio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbCaracteristicas;
        private System.Windows.Forms.Button btListarPeliculasSegunCaracteristicas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbDirector;
        private System.Windows.Forms.TextBox tbAnio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView listViewReporte;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Button btSalir;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbGeneroReporte;
        private System.Windows.Forms.TextBox tbDuracionReporte;
    }
}