﻿using System;
using System.Collections.Generic;
using Parcial_p.entities;
using MoreLinq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_p.Controller
{
    public class PeliculaController
    {
        public static List<Pelicula> Peliculas = new List<Pelicula>();

        public bool Existe(String Codigo)
        {
            List<Director> directores = DirectorController.ListarTodo();

            foreach(Director director in directores)
            {
                bool existe = director.peliculas.Exists(elemento => elemento.Codigo.Equals(Codigo));
                if (existe)
                {
                    return true;
                }
            }
            return false;
        }

        public void Registrar(String Dni , Pelicula pelicula)
        {
            List<Director> directors = DirectorController.ListarTodo();

            Director director = directors.Find(elemento => elemento.DNI.Equals(Dni));

            if(director != null)
            {
                director.peliculas.Add(pelicula);
            }

        }

        public List<Pelicula> ListarTodo(String Dni)
        {
            List<Director> directors = DirectorController.ListarTodo();

            Director director = directors.Find(elemento => elemento.DNI.Equals(Dni));

            if(director != null)
            {
                return director.peliculas;
            }
            else
            {
                return new List<Pelicula>();
            }
        }


        public List<Pelicula> Listarlaspeliculasmastaquillerasdeunanioespecifico(String Anio)
        {
            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> peliculasMasTaquilleras = new List<Pelicula>();
            int maxTaquilla = -1;

            foreach (Director director in directors)
            {
                List<Pelicula> peliculasDelAnio = director.peliculas.FindAll(pelicula => pelicula.AnioEstreno.Equals(Anio));

                if (peliculasDelAnio.Count > 0)
                {
                    Pelicula peliculaMasTaquillera = peliculasDelAnio.MaxBy(pelicula => pelicula.TaquillaGenerada).First();

                    if (peliculaMasTaquillera.TaquillaGenerada > maxTaquilla)
                    {
                        maxTaquilla = peliculaMasTaquillera.TaquillaGenerada;
                        peliculasMasTaquilleras.Clear();
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                    else if (peliculaMasTaquillera.TaquillaGenerada == maxTaquilla)
                    {
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                }
            }

            return peliculasMasTaquilleras;
        }
        
        public List<Pelicula> ListarLasPeliculasMasTaquillerasDeUnAnioEspecifico(string anio)
        {

            List<Director> directores = DirectorController.ListarTodo();
            List<Pelicula> peliculasMasTaquilleras = new List<Pelicula>();
            int maxTaquilla = -1;


            foreach (Director director in directores)
            {
                List<Pelicula> peliculasDelAnio = director.peliculas.FindAll(pelicula => pelicula.AnioEstreno.Equals(anio));

                if (peliculasDelAnio.Count > 0)
                {

                    Pelicula peliculaMasTaquillera = peliculasDelAnio.MaxBy(pelicula => pelicula.TaquillaGenerada).First();

                    if (peliculaMasTaquillera.TaquillaGenerada > maxTaquilla)
                    {
                        maxTaquilla = peliculaMasTaquillera.TaquillaGenerada;
                        peliculasMasTaquilleras.Clear();
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                    else if (peliculaMasTaquillera.TaquillaGenerada == maxTaquilla)
                    {
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                }
            }

            return peliculasMasTaquilleras;
        }

        public List<Pelicula> Listarlaspeliculasmastaquillerasporcadadirector(String NombreDirector)
        {

            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> pelitmp = new List<Pelicula>();
            int maxTaquilla = 0;

            foreach (Director director in directors)
            {
                if (director.NombreCompleto.Equals(NombreDirector))
                {
                    Pelicula peli = director.peliculas.MaxBy(i => i.TaquillaGenerada).First();
                    if(peli != null)
                    {
                        if(peli.TaquillaGenerada > maxTaquilla)
                        {
                            maxTaquilla = peli.TaquillaGenerada;
                            pelitmp.Clear();
                            pelitmp.Add(peli);

                        }
                        else if (peli.TaquillaGenerada == maxTaquilla)
                        {
                            pelitmp.Add(peli);
                        }
                    }
                }
            }

            return pelitmp;
        }

        public List<Pelicula> Listarlaspeliculassegúnsuscaracteristicas(int duracion, String Genero)
        {
            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> pelitmp = new List<Pelicula>();

            foreach (Director director in directors)
            {
                List<Pelicula> peliGenero = director.peliculas.FindAll(pelicula => pelicula.Genero.Equals(Genero));

                if (peliGenero.Count > 0)
                {
                    pelitmp = peliGenero.FindAll(elemento => elemento.Duracion.Equals(duracion));
                    
                }
            }

            return pelitmp;

        }

        public List<Pelicula> Listarlaspeliculassegúnsuscaracteristicasgenero(String Genero)
        {
            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> pelitmp = new List<Pelicula>();

            foreach (Director director in directors)
            {
                List<Pelicula> peliGenero = director.peliculas.FindAll(pelicula => pelicula.Genero.Equals(Genero));

               if(peliGenero.Count > 0)
                {
                    pelitmp = peliGenero;
                }
            }

            return pelitmp;
        }

    }


}
