﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial_p.entities
{
    public class Director
    {
        public Director () { }

        public String DNI { get; set; }
        public String NombreCompleto { get; set; }
        public String Sexo { get; set; }
        public String Estado { get; set; }
        public String Telefono { get; set; }
        public List<Pelicula> peliculas { get; set; }
    }
}
