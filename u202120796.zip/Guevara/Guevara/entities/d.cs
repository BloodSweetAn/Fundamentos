﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guevara.entities
{
    public class d
    {
        public d() { }
        public String Nombre { get; set; }
        public String Codigo { get; set; }
        public String Genero { get; set; }
        public String Estado { get; set; }
        public int Duracion { get; set; }
        public int TaquillaGenerada { get; set; }
        public String AnioEstreno { get; set; }
    }
}
