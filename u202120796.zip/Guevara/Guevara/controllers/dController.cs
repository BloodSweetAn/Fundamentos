﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Guevara.entities;
using MoreLinq;

namespace Guevara.controllers
{
    class dController
    {


        /*
         *public static List<Pelicula> Peliculas = new List<Pelicula>();

        public bool Existe(String Codigo)
        {
            List<Director> directores = DirectorController.ListarTodo();

            foreach(Director director in directores)
            {
                bool existe = director.peliculas.Exists(elemento => elemento.Codigo.Equals(Codigo));
                if (existe)
                {
                    return true;
                }
            }
            return false;
        }

        public void Registrar(String Dni , Pelicula pelicula)
        {
            List<Director> directors = DirectorController.ListarTodo();

            Director director = directors.Find(elemento => elemento.DNI.Equals(Dni));

            if(director != null)
            {
                director.peliculas.Add(pelicula);
            }

        }

        public List<Pelicula> ListarTodo(String Dni)
        {
            List<Director> directors = DirectorController.ListarTodo();

            Director director = directors.Find(elemento => elemento.DNI.Equals(Dni));

            if(director != null)
            {
                return director.peliculas;
            }
            else
            {
                return new List<Pelicula>();
            }
        }


        public List<Pelicula> Listarlaspeliculasmastaquillerasdeunanioespecifico(String Anio)
        {
            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> peliculasMasTaquilleras = new List<Pelicula>();
            int maxTaquilla = -1;

            foreach (Director director in directors)
            {
                List<Pelicula> peliculasDelAnio = director.peliculas.FindAll(pelicula => pelicula.AnioEstreno.Equals(Anio));

                if (peliculasDelAnio.Count > 0)
                {
                    Pelicula peliculaMasTaquillera = peliculasDelAnio.MaxBy(pelicula => pelicula.TaquillaGenerada).First();

                    if (peliculaMasTaquillera.TaquillaGenerada > maxTaquilla)
                    {
                        maxTaquilla = peliculaMasTaquillera.TaquillaGenerada;
                        peliculasMasTaquilleras.Clear();
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                    else if (peliculaMasTaquillera.TaquillaGenerada == maxTaquilla)
                    {
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                }
            }

            return peliculasMasTaquilleras;
        }
        
        public List<Pelicula> ListarLasPeliculasMasTaquillerasDeUnAnioEspecifico(string anio)
        {

            List<Director> directores = DirectorController.ListarTodo();
            List<Pelicula> peliculasMasTaquilleras = new List<Pelicula>();
            int maxTaquilla = -1;


            foreach (Director director in directores)
            {
                List<Pelicula> peliculasDelAnio = director.peliculas.FindAll(pelicula => pelicula.AnioEstreno.Equals(anio));

                if (peliculasDelAnio.Count > 0)
                {

                    Pelicula peliculaMasTaquillera = peliculasDelAnio.MaxBy(pelicula => pelicula.TaquillaGenerada).First();

                    if (peliculaMasTaquillera.TaquillaGenerada > maxTaquilla)
                    {
                        maxTaquilla = peliculaMasTaquillera.TaquillaGenerada;
                        peliculasMasTaquilleras.Clear();
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                    else if (peliculaMasTaquillera.TaquillaGenerada == maxTaquilla)
                    {
                        peliculasMasTaquilleras.Add(peliculaMasTaquillera);
                    }
                }
            }

            return peliculasMasTaquilleras;
        }

        public List<Pelicula> Listarlaspeliculasmastaquillerasporcadadirector(String NombreDirector)
        {

            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> pelitmp = new List<Pelicula>();
            int maxTaquilla = 0;

            Director directorSeleccionado = directors.Find(d => d.NombreCompleto.Equals(NombreDirector));

            foreach(Pelicula p in directorSeleccionado.peliculas)
            {
                int maxTaquillaPelicula = p.TaquillaGenerada;

                if (maxTaquillaPelicula > maxTaquilla)
                {
                    pelitmp.Clear();
                    maxTaquilla = maxTaquillaPelicula;
                    pelitmp.Add(p);
                }
                else if(maxTaquillaPelicula == maxTaquilla)
                {
                    maxTaquilla = maxTaquillaPelicula;
                    pelitmp.Add(p);
                }
            }

            return pelitmp;
        }

        public List<Pelicula> Listarlaspeliculassegúnsuscaracteristicas(int duracion, String Genero)
        {
            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> pelitmp = new List<Pelicula>();

            foreach (Director director in directors)
            {
                List<Pelicula> peliGenero = director.peliculas.FindAll(pelicula => pelicula.Genero.Equals(Genero));

                if (peliGenero.Count > 0)
                {
                    pelitmp.AddRange(peliGenero.FindAll(elemento => elemento.Duracion.Equals(duracion)));
                    
                }
            }

            return pelitmp;

        }

        public List<Pelicula> Listarlaspeliculassegúnsuscaracteristicasgenero(String Genero)
        {
            List<Director> directors = DirectorController.ListarTodo();
            List<Pelicula> pelitmp = new List<Pelicula>();

            foreach (Director director in directors)
            {
                List<Pelicula> peliGenero = director.peliculas.FindAll(pelicula => pelicula.Genero.Equals(Genero));

               if(peliGenero.Count > 0)
                {
                    pelitmp.AddRange(peliGenero);
                }
            }

            return pelitmp;
        }
         */
    }
}
