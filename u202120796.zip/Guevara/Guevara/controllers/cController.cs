﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Guevara.entities;
using MoreLinq;

namespace Guevara.controllers
{
    class cController
    {
        private static List<c> C = new List<c>();
        public cController() { }

        public bool Existe(String Dni)
        {
            return C.Exists(elemento => elemento.DNI.Equals(Dni));
        }

        public void Registrar(c director)
        {
            C.Add(director);
        }

        public static List<c> ListarTodo()
        {
            return C;
        }
    }
}
