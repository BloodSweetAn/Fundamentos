﻿
namespace Guevara
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btVer = new System.Windows.Forms.Button();
            this.btSalirPrincipal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btVer
            // 
            this.btVer.Location = new System.Drawing.Point(89, 65);
            this.btVer.Name = "btVer";
            this.btVer.Size = new System.Drawing.Size(153, 32);
            this.btVer.TabIndex = 0;
            this.btVer.Text = "Ver";
            this.btVer.UseVisualStyleBackColor = true;
            // 
            // btSalirPrincipal
            // 
            this.btSalirPrincipal.Location = new System.Drawing.Point(108, 154);
            this.btSalirPrincipal.Name = "btSalirPrincipal";
            this.btSalirPrincipal.Size = new System.Drawing.Size(113, 37);
            this.btSalirPrincipal.TabIndex = 1;
            this.btSalirPrincipal.Text = "Salir";
            this.btSalirPrincipal.UseVisualStyleBackColor = true;
            this.btSalirPrincipal.Click += new System.EventHandler(this.btSalirPrincipal_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 274);
            this.Controls.Add(this.btSalirPrincipal);
            this.Controls.Add(this.btVer);
            this.Name = "FormPrincipal";
            this.Text = "FormPrincipal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btVer;
        private System.Windows.Forms.Button btSalirPrincipal;
    }
}