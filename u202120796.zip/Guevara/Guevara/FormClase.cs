﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guevara.entities;
using Guevara.reports;

namespace Guevara
{
    public partial class FormClase : Form
    {
        public FormClase()
        {
            InitializeComponent();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btReporte_Click(object sender, EventArgs e)
        {
            FormReporte formReporte = new FormReporte();
            formReporte.Show();
        }
    }
}

/*
 
if(tbDni.Text == "" || tbNombreCompleto.Text == "" || tbTelefono.Text == "" || cbEstado.Text== "" || cbSexo.Text == "")
            {
                MessageBox.Show("Ingrese nuevamente los datos");
                return;
            }

            Director director = new Director()
            {
                NombreCompleto = tbNombreCompleto.Text,
                Telefono = tbTelefono.Text,
                DNI = tbDni.Text,
                Estado = cbEstado.Text,
                Sexo = cbSexo.Text,
                peliculas = new List<Pelicula>()
            };

            bool registrado = directorReporte.Registrar(director);
            if (!registrado)
            {
                MessageBox.Show("Ingrese un Dni diferente , este ya esta registrado");
                return;
            }

            tbDni.Text = "";
            tbNombreCompleto.Text = "";
            tbTelefono.Text = "";
            cbEstado.Text = "";
            cbSexo.Text = "";

            MostrarDirector(directorReporte.ListarTodo());
        }

        private void btVerPeliculas_Click(object sender, EventArgs e)
        {
            if( listViewDirector.SelectedItems.Count == 0)
            {
                MessageBox.Show("Seleccione un director");
                return;
            }

            String codigo = listViewDirector.SelectedItems[0].Text;

            FormPelicula formPelicula = new FormPelicula(codigo);
            formPelicula.Show();
        }
 */