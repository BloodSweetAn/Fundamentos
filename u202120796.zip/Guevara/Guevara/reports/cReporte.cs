﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Guevara.entities;
using Guevara.controllers;

namespace Guevara.reports
{
    class cReporte
    {
        /*
         private DirectorController directorController = new DirectorController();

        public DirectorReporte() { }

        public bool Registrar(Director director)
        {
            if (directorController.Existe(director.DNI))
            {
                return false;
            }
            else
            {
                directorController.Registrar(director);
                return true;
            }
        } 

        public List<Director> ListarTodo()
        {
            return DirectorController.ListarTodo();
        }
        
         */
    }
}
